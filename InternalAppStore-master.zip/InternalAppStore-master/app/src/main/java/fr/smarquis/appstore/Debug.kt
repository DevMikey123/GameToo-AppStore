package fr.smarquis.appstore

val DEBUG_SCREENSHOT_STATUS: Pair<Version.Status, Int>? by lazy {
    /*Version.Status.DOWNLOADING to 66*/
    /*Version.Status.INSTALLING*/
    /*Version.Status.DEFAULT to 0*/
    null
}